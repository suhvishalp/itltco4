package com.demo.repositories;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.demo.entities.OwnClass;

public class AbRepository {
	
	

}
