package com.demo.entities;

public class OwnClass {

}
